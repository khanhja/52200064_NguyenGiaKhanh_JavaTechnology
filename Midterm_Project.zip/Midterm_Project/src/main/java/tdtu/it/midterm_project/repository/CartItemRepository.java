package tdtu.it.midterm_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tdtu.it.midterm_project.model.Cart;
import tdtu.it.midterm_project.model.CartItem;
import tdtu.it.midterm_project.model.Product;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem, Integer> {
    CartItem findByCartAndProduct(Cart cart, Product product);
    int countByCart(Cart cart);
    List<CartItem> findByCart(Cart cart);
}
