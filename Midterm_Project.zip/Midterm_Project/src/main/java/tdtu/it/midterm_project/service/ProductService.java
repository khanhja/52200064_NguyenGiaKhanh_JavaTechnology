package tdtu.it.midterm_project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tdtu.it.midterm_project.model.Category;
import tdtu.it.midterm_project.model.Product;
import tdtu.it.midterm_project.repository.CategoryRepository;
import tdtu.it.midterm_project.repository.ProductRepository;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    // Phương thức lấy tất cả sản phẩm
    public List<Category> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return groupProductsByCategory(products);
    }

    public List<Category> getFilteredProducts(String category, String brand, String priceRange, String color) {
        int minPrice = 0;
        int maxPrice = Integer.MAX_VALUE;

        if (priceRange != null && !priceRange.isEmpty()) {
            String[] priceParts = priceRange.split("-");
            minPrice = Integer.parseInt(priceParts[0]);
            if (priceParts.length > 1)
                maxPrice = Integer.parseInt(priceParts[1]);
            else
                maxPrice = Integer.MAX_VALUE;
        }

        // Lọc sản phẩm theo bộ lọc
        List<Product> filteredProducts = productRepository.findFilteredProducts(category, brand, color, minPrice, maxPrice);

        return groupProductsByCategory(filteredProducts);
    }

    public List<Product> searchByName(String query) {
        // Tìm kiếm sản phẩm có tên chứa từ khóa
        return productRepository.findByNameContainingIgnoreCase(query);
    }

    public Product findById(int id) { return productRepository.getById(id); }

    public List<Category> groupProductsByCategory(List<Product> products) {
        // Lấy tất cả category hiện có
        List<Category> allCategories = categoryRepository.findAll();

        // Duyệt qua tất cả các category và thêm sản phẩm vào category nếu có sản phẩm phù hợp
        for (Category cat : allCategories) {
            // Lọc các sản phẩm thuộc category này
            List<Product> productsInCategory = products.stream()
                    .filter(product -> product.getCategory().getName().equals(cat.getName()))
                    .collect(Collectors.toList());

            // Nếu có sản phẩm, gán vào category và thêm vào danh sách filteredCategories
            if (!productsInCategory.isEmpty())
                cat.setProducts(productsInCategory);
            else
                cat.setProducts(Collections.emptyList()); // Đảm bảo không có sản phẩm thì trả về danh sách rỗng
        }
        // Loại bỏ category không có sản phẩm
        return allCategories.stream()
                .filter(cat -> !cat.getProducts().isEmpty())
                .collect(Collectors.toList());
    }

}

