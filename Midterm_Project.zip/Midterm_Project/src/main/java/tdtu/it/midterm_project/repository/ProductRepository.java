package tdtu.it.midterm_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import tdtu.it.midterm_project.model.Category;
import tdtu.it.midterm_project.model.Product;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Integer> {
    @Query("SELECT p FROM Product p WHERE " +
            "(COALESCE(:category, '') = '' OR p.category.name = :category) AND " +
            "(COALESCE(:brand, '') = '' OR p.brand = :brand) AND " +
            "(p.price BETWEEN :minPrice AND :maxPrice) AND " +
            "(COALESCE(:color, '') = '' OR p.color = :color)")
    List<Product> findFilteredProducts(@Param("category") String category,
                                       @Param("brand") String brand,
                                       @Param("color") String color,
                                       @Param("minPrice") Integer minPrice,
                                       @Param("maxPrice") Integer maxPrice);

    List<Product> findByNameContainingIgnoreCase(String name);
}
