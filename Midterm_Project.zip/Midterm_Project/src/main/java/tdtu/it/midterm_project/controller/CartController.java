package tdtu.it.midterm_project.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tdtu.it.midterm_project.dto.ApiResponse;
import tdtu.it.midterm_project.dto.ItemDTO;
import tdtu.it.midterm_project.model.Cart;
import tdtu.it.midterm_project.model.CartItem;
import tdtu.it.midterm_project.service.CartService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public ResponseEntity<?> addToCart(HttpSession session, @RequestBody ItemDTO itemDTO) {
        // Sử dụng CartService để xử lý logic thêm sản phẩm vào giỏ hàng
        cartService.addProductToCart(session, itemDTO);

        // Trả về thông báo dưới dạng JSON
        Map<String, String> response = new HashMap<>();
        response.put("message", "Successfully added product to the cart");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Integer>> getCartItemCount(HttpSession session) {
        Integer cartId = (Integer) session.getAttribute("cartId");

        if (cartId == null)
            return ResponseEntity.ok(Map.of("count", 0));

        // Lấy số lượng sản phẩm trong giỏ từ CartService
        int itemCount = cartService.getCartItemCount(cartId);

        return ResponseEntity.ok(Map.of("count", itemCount));
    }

    // Hiển thị giỏ hàng
    @GetMapping("/show")
    public String showCart(HttpSession session, Model model) {
        List<CartItem> cartItems = cartService.getCartItems(session);
        int total = cartService.calculateTotal(session);

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("total", total);

        return "cart.html";
    }

    @PostMapping("/update")
    public ResponseEntity<?> updateCartItem(
            @RequestBody ItemDTO request,
            HttpSession session) {

        // Lấy mã giỏ hàng từ session
        Integer cartId = (Integer) session.getAttribute("cartId");
        if (cartId == null)
            return ResponseEntity.ok(new ApiResponse(false, "Giỏ hàng hiện tại trống."));

        // Lấy giỏ hàng từ database
        Cart cart = cartService.getCartById(cartId);
        if (cart == null)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Giỏ hàng không tồn tại."));

        // Cập nhật số lượng sản phẩm trong giỏ hàng
        boolean updated = cartService.updateItemQuantity(cartId, request.getProductId(), request.getQuantity());
        if (!updated)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(false, "Sản phẩm không tồn tại trong giỏ hàng."));

        // Tính toán lại tổng giá trị giỏ hàng sau khi cập nhật
        double total = cartService.calculateTotal(session);

        // Trả về kết quả
        return ResponseEntity.ok(new ApiResponse(true, "Cập nhật giỏ hàng thành công.", total));
    }

    @PostMapping("/remove")
    public ResponseEntity<?> removeProductFromCart(@RequestBody ItemDTO request, HttpSession session) {
        Integer cartId = (Integer) session.getAttribute("cartId");
        if (cartId == null)
            return ResponseEntity.ok(new ApiResponse(false, "Giỏ hàng hiện tại trống."));

        // Xử lý xóa sản phẩm khỏi giỏ hàng
        boolean removed = cartService.removeItemFromCart(cartId, request.getProductId());
        if (!removed)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(false, "Không thể xóa sản phẩm."));

        // Tính toán lại tổng giá trị giỏ hàng sau khi xóa
        double total = cartService.calculateTotal(session);

        // Trả về kết quả
        return ResponseEntity.ok(new ApiResponse(true, "Sản phẩm đã được xóa khỏi giỏ hàng.", total));
    }

    @PostMapping("/clear-session")
    @ResponseBody
    public ResponseEntity<?> clearCart(HttpSession session) {
        // Xóa giỏ hàng khỏi session
        session.removeAttribute("cartId");

        // Trả về phản hồi JSON
        return ResponseEntity.ok(new ApiResponse(true, "Cart cleared in session."));
    }
}
