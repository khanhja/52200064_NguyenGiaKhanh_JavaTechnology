package tdtu.it.midterm_project.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "Category")
@Data
public class Category {

    @Id
    @Column(name = "category_id", length = 50)
    private String categoryId; // Tương ứng với VARCHAR(50)

    @Column(name = "name", nullable = false, length = 255)
    private String name; // Tương ứng với VARCHAR(255)

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Product> products; // Danh sách sản phẩm thuộc danh mục
}


