package tdtu.it.midterm_project.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tdtu.it.midterm_project.model.Category;
import tdtu.it.midterm_project.model.Product;
import tdtu.it.midterm_project.service.CartService;
import tdtu.it.midterm_project.service.ProductService;

import java.util.Collections;
import java.util.List;

@Controller
public class HomeController {
    @Autowired
    private ProductService productService;

    @Autowired
    private CartService cartService;

    @GetMapping("/home")
    public String index(HttpSession session, Model model) {
        Integer cartId = (Integer) session.getAttribute("cartId");
        int totalItems = 0;

        // Nếu có cartId trong session, lấy số lượng sản phẩm trong giỏ
        if (cartId != null)
            totalItems = cartService.getCartItemCount(cartId);

        model.addAttribute("cartItemCount", totalItems);
        model.addAttribute("categories", productService.getAllProducts());
        return "index";
    }

    // Phương thức xử lý lọc sản phẩm khi người dùng truy cập /filter
    @GetMapping("/filter")
    public String filter(Model model,
                         @RequestParam(required = false) String category,
                         @RequestParam(required = false) String brand,
                         @RequestParam(required = false) String priceRange,
                         @RequestParam(required = false) String color) {

        if (category.isEmpty() && brand.isEmpty() && priceRange.isEmpty() && color.isEmpty())
            return "redirect:/home";

        List<Category> filteredCategories = productService.getFilteredProducts(category, brand, priceRange, color);

        model.addAttribute("categories", filteredCategories);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedBrand", brand);
        model.addAttribute("selectedPriceRange", priceRange);
        model.addAttribute("selectedColor", color);

        return showNotFoundMessage(model, filteredCategories);
    }

    @RequestMapping("/search")
    @ResponseBody
    public List<Product> searchProductsJson(@RequestParam("query") String query) {
        return productService.searchByName(query);
    }

    // Phương thức xử lý tìm kiếm sản phẩm theo tên
    @GetMapping("/search-by-specific")
    public String searchBySpecific(@RequestParam("productName") String productName, Model model) {
        List<Product> products = productService.searchByName(productName);
        List<Category> categories = productService.groupProductsByCategory(products);
        return showNotFoundMessage(model, categories);
    }

    private String showNotFoundMessage(Model model, List<Category> categories) {
        if (categories.isEmpty()) {
            Category noProductsCategory = new Category();
            noProductsCategory.setName("No products available");
            noProductsCategory.setProducts(Collections.emptyList());
            model.addAttribute("categories", Collections.singletonList(noProductsCategory));
        }
        else
            model.addAttribute("categories", categories);

        return "index";
    }
}
