package tdtu.it.midterm_project.service;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tdtu.it.midterm_project.dto.ItemDTO;
import tdtu.it.midterm_project.model.Cart;
import tdtu.it.midterm_project.model.CartItem;
import tdtu.it.midterm_project.model.Product;
import tdtu.it.midterm_project.repository.CartItemRepository;
import tdtu.it.midterm_project.repository.CartRepository;
import tdtu.it.midterm_project.repository.ProductRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    public void addProductToCart(HttpSession session, ItemDTO itemDTO) {
        // Kiểm tra xem session đã có mã cart chưa
        Integer cartId = (Integer) session.getAttribute("cartId");

        if (cartId == null) {
            // Nếu chưa có cart trong session, tạo mới cart và lưu vào CSDL
            Cart newCart = createNewCart();
            cartId = newCart.getId();  // Lấy mã cart
            session.setAttribute("cartId", cartId);  // Lưu cartId vào session
        }

        // Lấy Product từ productId
        Product product = productRepository.findById(itemDTO.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Lấy Cart từ cartId trong session
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        // Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
        CartItem existingCartItem = cartItemRepository.findByCartAndProduct(cart, product);

        if (existingCartItem != null) {
            // Nếu đã có CartItem cho sản phẩm này, cộng dồn quantity
            existingCartItem.setQuantity(existingCartItem.getQuantity() + itemDTO.getQuantity());
            cartItemRepository.save(existingCartItem);  // Cập nhật CartItem
        } else {
            // Nếu chưa có, tạo CartItem mới và lưu vào CSDL
            CartItem newCartItem = new CartItem(cart, product, itemDTO.getQuantity());
            cartItemRepository.save(newCartItem);
        }
    }

    // Tạo cart mới
    public Cart createNewCart() {
        Cart cart = new Cart();
        return cartRepository.save(cart);
    }

    // Phương thức lấy số lượng sản phẩm trong giỏ
    public int getCartItemCount(int cartId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
        return cartItemRepository.countByCart(cart);
    }

    // Lấy tất cả CartItem của giỏ hàng
    public List<CartItem> getCartItems(HttpSession session) {
        Integer cartId = (Integer) session.getAttribute("cartId");

        if (cartId == null)
            return new ArrayList<>();  // Nếu không có cartId trong session, trả về giỏ hàng trống

        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        return cartItemRepository.findByCart(cart);  // Lấy tất cả CartItem từ giỏ hàng
    }

    // Lấy tổng giá trị giỏ hàng
    public int calculateTotal(HttpSession session) {
        List<CartItem> cartItems = getCartItems(session);

        return cartItems.stream()
                .mapToInt(item -> item.getProduct().getPrice() * item.getQuantity())
                .sum();
    }

    // Cập nhật số lượng sản phẩm trong giỏ hàng
    public boolean updateItemQuantity(int cartId, int productId, int quantity) {
        Product product = productRepository.findById(productId).orElse(null);
        Cart cart = cartRepository.findById(cartId).orElse(null);
        CartItem item = cartItemRepository.findByCartAndProduct(cart, product);
        if (item != null) {
            item.setQuantity(quantity);
            cartItemRepository.save(item);
            return true;
        }
        return false;
    }

    public Cart getCartById(int cartId) {
        return cartRepository.findById(cartId).orElse(null);
    }

    // Phương thức xóa sản phẩm khỏi giỏ hàng
    public boolean removeItemFromCart(int cartId, int productId) {
        // Lấy giỏ hàng từ database
        Cart cart = cartRepository.findById(cartId).orElse(null);
        if (cart == null)
            return false; // Giỏ hàng không tồn tại

        // Tìm sản phẩm trong giỏ hàng
        Product product = productRepository.findById(productId).orElse(null);
        CartItem cartItem = cartItemRepository.findByCartAndProduct(cart, product);
        if (cartItem == null)
            return false; // Sản phẩm không có trong giỏ hàng

        // Xóa sản phẩm khỏi giỏ hàng
        cartItemRepository.delete(cartItem);

        return true;
    }
}