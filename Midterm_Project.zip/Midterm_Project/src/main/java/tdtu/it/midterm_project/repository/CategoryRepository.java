package tdtu.it.midterm_project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tdtu.it.midterm_project.model.Category;

public interface CategoryRepository extends JpaRepository<Category, String> {
}


