package tdtu.it.midterm_project.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import tdtu.it.midterm_project.dto.ApiResponse;
import tdtu.it.midterm_project.dto.DeliveryInfoRequest;
import tdtu.it.midterm_project.model.CartItem;
import tdtu.it.midterm_project.model.DeliveryInfo;
import tdtu.it.midterm_project.service.CartService;
import tdtu.it.midterm_project.service.DeliveryInfoService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class PlaceOrderController {
    @Autowired
    private CartService cartService;

    @Autowired
    private DeliveryInfoService deliveryInfoService;

    @GetMapping("/place-order")
    public String showDeliveryForm(HttpSession session, Model model) {
        List<CartItem> cartItems = cartService.getCartItems(session);
        int total = cartService.calculateTotal(session);

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalAmount", total);
        return "placeOrder";
    }

    @PostMapping("/save-delivery-info")
    @ResponseBody
    public ResponseEntity<?> placeOrder(@RequestBody DeliveryInfoRequest request, HttpSession session) throws ParseException {
        // Lưu thông tin giao hàng vào cơ sở dữ liệu
        DeliveryInfo deliveryInfo = new DeliveryInfo();
        deliveryInfo.setFullName(request.getFullName());
        // Chuyển đổi từ String sang Date
        String dobString = request.getDob();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dob = dateFormat.parse(dobString);
        deliveryInfo.setDob(dob);
        deliveryInfo.setGender(request.getGender());
        deliveryInfo.setPhone(request.getPhone());
        deliveryInfo.setAddress(request.getAddress());

        // Lưu vào cơ sở dữ liệu
        DeliveryInfo savedDeliveryInfo = deliveryInfoService.save(deliveryInfo);

        // Lưu mã delivery_info vào session
        session.setAttribute("deliveryInfoID", savedDeliveryInfo.getId());

        // Trả về phản hồi
        return ResponseEntity.ok(new ApiResponse("Order placed successfully"));
    }
}
