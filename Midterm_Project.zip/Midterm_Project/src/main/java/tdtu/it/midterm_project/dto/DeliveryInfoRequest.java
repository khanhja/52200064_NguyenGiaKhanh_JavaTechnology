package tdtu.it.midterm_project.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeliveryInfoRequest {
    private String fullName;
    private String dob;
    private String gender;
    private String phone;
    private String address;
}

