package tdtu.it.midterm_project.service;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tdtu.it.midterm_project.model.DeliveryInfo;
import tdtu.it.midterm_project.repository.DeliveryInfoRepository;

@Service
public class DeliveryInfoService {

    @Autowired
    private DeliveryInfoRepository deliveryInfoRepository;

    public DeliveryInfo save(DeliveryInfo deliveryInfo) {
        return deliveryInfoRepository.save(deliveryInfo);
    }
}
