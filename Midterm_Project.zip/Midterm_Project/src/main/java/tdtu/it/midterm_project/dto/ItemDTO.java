package tdtu.it.midterm_project.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItemDTO {
    private int productId;
    private int quantity;
}

