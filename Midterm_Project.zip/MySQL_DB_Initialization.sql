CREATE DATABASE sportshop;
USE sportshop;

-- Product
CREATE TABLE Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,           -- id tự động tăng và làm khóa chính
    name VARCHAR(255) NOT NULL,                   -- Tên sản phẩm
    brand VARCHAR(255),                           -- Nhãn hàng
    price INT NOT NULL,                			  -- Giá sản phẩm (kiểu số với 3 chữ số thập phân)
    color VARCHAR(50),                            -- Màu sắc
    quantity INT DEFAULT 0,                       -- Số lượng
    description TEXT,                             -- Mô tả thêm
    image_uri VARCHAR(255),                       -- Đường dẫn lưu ảnh
    category_id VARCHAR(50),                      -- Mã danh mục (hiện tại ẩn khóa ngoại)
    FOREIGN KEY (category_id) REFERENCES Category(category_id)
);

-- Catagory
CREATE TABLE Category (
    category_id VARCHAR(50) PRIMARY KEY,      -- Mã danh mục
    name VARCHAR(255) NOT NULL                -- Tên danh mục
);

-- Cart
CREATE TABLE Cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY       -- Mã giỏ hàng
);

-- CartItem
CREATE TABLE Cart_Item (
    cart_item_id INT AUTO_INCREMENT PRIMARY KEY,       -- Mã mục giỏ hàng
    cart_id INT NOT NULL,                    -- Mã giỏ hàng (khóa ngoại)
    product_id INT NOT NULL,                 -- Mã sản phẩm (khóa ngoại)
    quantity INT NOT NULL,                   -- Số lượng sản phẩm
    FOREIGN KEY (cart_id) REFERENCES Cart(cart_id), -- Khóa ngoại liên kết đến bảng Cart
    FOREIGN KEY (product_id) REFERENCES Product(product_id) -- Khóa ngoại liên kết đến bảng Product
);

-- Delivery information
CREATE TABLE delivery_info (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Mã giao hàng
    full_name VARCHAR(255) NOT NULL,    -- Họ và tên
    dob DATE NOT NULL,                  -- Ngày sinh
    gender VARCHAR(10) NOT NULL,        -- Giới tính
    phone VARCHAR(15) NOT NULL,         -- Số điện thoại
    address TEXT NOT NULL               -- Địa chỉ
);

-- Sample data

-- Category
INSERT INTO Category (category_id, name) VALUES
('PICKLEBALL_RACKET', 'Pickleball Rackets'),
('BASEBALL_BAT', 'Baseball Bats'),
('BADMINTON_RACKET', 'Badminton Rackets'),
('ACCESSORIES', 'Accessories');


-- Product

-- Pickleball rackets
INSERT INTO Product (name, brand, price, color, quantity, description, image_uri, category_id) VALUES
('Pickleball Pro Racket', 'ProSport', 2300000, 'Green', 50, 'High-performance pickleball racket with lightweight design', '/images/pickleball_racket_1.webp', 'PICKLEBALL_RACKET'),
('Advanced Pickleball Racket', 'SportMaster', 1799000, 'Black', 60, 'Durable racket for competitive play', '/images/pickleball_racket_2.webp', 'PICKLEBALL_RACKET'),
('Elite Pickleball Paddle', 'SportMaster', 2499000, 'Yellow', 40, 'Premium quality paddle with excellent control', '/images/pickleball_racket_3.jpg', 'PICKLEBALL_RACKET'),
('Beginner Pickleball Racket', 'EasyPlay', 250000, 'Green', 100, 'Affordable racket for beginners', '/images/pickleball_racket_4.webp', 'PICKLEBALL_RACKET'),
('Pro Pickleball Paddle', 'SportMaster', 600000, 'Red', 30, 'Professional-grade paddle for advanced players', '/images/pickleball_racket_5.webp', 'PICKLEBALL_RACKET'),
('Breeze Pickleball Racket', 'SportMaster', 1350000, 'Ocean', 45, 'Sleek racket with ocean-inspired design', '/images/pickleball_racket_6.webp', 'PICKLEBALL_RACKET'),
('Power Pickleball Paddle for Beginner', 'EasyPlay', 380000, 'Pink', 55, 'Stylish paddle with vibrant color for players', '/images/pickleball_racket_7.webp', 'PICKLEBALL_RACKET'),
('Lightning Pickleball Racket for Beginner', 'EasyPlay', 450000, 'White', 35, 'Premium racket designed for speed and precision', '/images/pickleball_racket_8.webp', 'PICKLEBALL_RACKET');


-- Baseball bats
INSERT INTO Product (name, brand, price, color, quantity, description, image_uri, category_id) VALUES
('Power Hit Baseball Bat', 'BatMaster', 550000, 'Ocean', 70, 'High-performance bat designed for power hitters', '/images/baseball_bat_1.jpg', 'BASEBALL_BAT'),
('Elite Pro Baseball Bat', 'ProSwing', 2200000, 'Pink', 50, 'Lightweight and durable bat for professional play', '/images/baseball_bat_2.jpg', 'BASEBALL_BAT'),
('Classic Baseball Bat', 'ProSwing', 300000, 'Black', 80, 'Traditional wooden bat for casual players', '/images/baseball_bat_3.webp', 'BASEBALL_BAT'),
('Speedster Baseball Bat', 'BatMaster', 1250000, 'Yellow', 60, 'Bat optimized for fast swing and quick contact', '/images/baseball_bat_4.webp', 'BASEBALL_BAT');


-- Badminton rackets
INSERT INTO Product (name, brand, price, color, quantity, description, image_uri, category_id) VALUES
('Champion Badminton Racket', 'Yonex', 450000, 'Pink', 90, 'High-quality racket for professional badminton players', '/images/badminton_racket_1.jpg', 'BADMINTON_RACKET'),
('Speed X Badminton Racket', 'Yonex', 600000, 'Red', 70, 'Lightweight and fast racket for advanced players', '/images/badminton_racket_2.jpg', 'BADMINTON_RACKET'),
('Allrounder Badminton Racket', 'Yonex', 350000, 'White', 100, 'Versatile racket suitable for all types of players', '/images/badminton_racket_3.webp', 'BADMINTON_RACKET'),
('Beginner Badminton Racket', 'EasyPlay', 250000, 'Yellow', 120, 'Affordable racket for beginners with a comfortable grip', '/images/badminton_racket_4.jpg', 'BADMINTON_RACKET');


